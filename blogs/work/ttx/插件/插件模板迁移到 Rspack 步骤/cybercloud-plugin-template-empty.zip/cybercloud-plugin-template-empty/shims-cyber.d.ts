type Cyber = {};

declare const cyber: any;
