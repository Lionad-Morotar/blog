
    import { createApp } from 'vue'
    import App from '/src/dialogs/example/index.vue'
    import entry from '/src/dialogs/example/index.js'
    const renderNodeId = '#expose-dialogs-root'
    const app = createApp(App)
    if(entry.created) {
      entry.created(app)
    }
    app.mount(renderNodeId)
    if(entry.mounted) {
       entry.mounted(app,renderNodeId)
    }
    