const map = new Map();

export default map;
